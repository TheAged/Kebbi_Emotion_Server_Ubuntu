import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class KebbiUploader {

    public static void uploadFile(String requestURL, String filePath, String fieldName) throws IOException {
        String boundary = Long.toHexString(System.currentTimeMillis());
        HttpURLConnection conn = (HttpURLConnection) new URL(requestURL).openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

        try (
            OutputStream output = conn.getOutputStream();
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(output, "UTF-8"), true)
        ) {
            File file = new File(filePath);
            writer.append("--" + boundary).append("\r\n");
            writer.append("Content-Disposition: form-data; name="" + fieldName + ""; filename="" + file.getName() + ""\r\n");
            writer.append("Content-Type: application/octet-stream\r\n\r\n").flush();
            try (FileInputStream inputStream = new FileInputStream(file)) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    output.write(buffer, 0, bytesRead);
                }
                output.flush();
            }
            writer.append("\r\n").flush();
            writer.append("--" + boundary + "--\r\n").flush();
        }

        int responseCode = conn.getResponseCode();
        if (responseCode != 200) {
            throw new IOException("Server returned non-OK status: " + responseCode);
        }
    }
}
