import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import com.nuwarobotics.sdk.NuwaRobotAPI;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    NuwaRobotAPI robot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        robot = NuwaRobotAPI.getInstance(this);

        try {
            robot.startRecord("/sdcard/input.wav");
            Thread.sleep(5000);
            robot.stopRecord();

            robot.takePicture("/sdcard/face.jpg");

            KebbiUploader.uploadFile("http://<server-ip>:5000/upload/audio", "/sdcard/input.wav", "audio");
            KebbiUploader.uploadFile("http://<server-ip>:5000/upload/image", "/sdcard/face.jpg", "image");

            JSONObject json = HttpJsonHelper.post("http://<server-ip>:5000/analyze");

            String emotion = json.getString("emotion");
            String tts = json.getString("response_text");

            robot.startTTS(tts);

            if ("快樂".equals(emotion)) robot.motionPlay("joyM_Ok", true);
            else if ("生氣".equals(emotion)) robot.motionPlay("angryM_Shake", true);
            else if ("悲傷".equals(emotion)) robot.motionPlay("sadM_SayNo", true);
            else robot.motionPlay("idle", true);

        } catch (Exception e) {
            Log.e("KebbiError", e.toString());
        }
    }
}
