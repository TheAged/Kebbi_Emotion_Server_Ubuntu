import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import com.nuwarobotics.sdk.NuwaRobotAPI;

import org.json.JSONObject;

public class FaceEmotionActivity extends AppCompatActivity {
    NuwaRobotAPI robot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        robot = NuwaRobotAPI.getInstance(this);

        try {
            robot.takePicture("/sdcard/face.jpg");

            KebbiUploader.uploadFile("http://<server-ip>:5000/upload/image", "/sdcard/face.jpg", "image");
            JSONObject json = HttpJsonHelper.post("http://<server-ip>:5000/analyze_face_only");

            String facialEmotion = json.getString("facial_emotion");

            if ("快樂".equals(facialEmotion)) robot.motionPlay("joyM_Ok", true);
            else if ("生氣".equals(facialEmotion)) robot.motionPlay("angryM_Shake", true);
            else if ("悲傷".equals(facialEmotion)) robot.motionPlay("sadM_SayNo", true);
            else robot.motionPlay("idle", true);

        } catch (Exception e) {
            Log.e("FaceEmotionError", e.toString());
        }
    }
}
