from transformers import AutoModelForAudioClassification, AutoFeatureExtractor
import torch
import numpy as np
import librosa
import cv2
from fer import FER

# 初始化 GPU 模型（Whisper fine-tuned emotion）
model_id = "firdhokk/speech-emotion-recognition-with-openai-whisper-large-v3"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
audio_model = AutoModelForAudioClassification.from_pretrained(model_id).to(device)
feature_extractor = AutoFeatureExtractor.from_pretrained(model_id, do_normalize=True)
id2label = audio_model.config.id2label

# 初始化 FER
face_emotion_detector = FER(mtcnn=True)

def detect_text_emotion(text):
    from main import safe_generate
    prompt = f"""你是一個情緒分析助手，請從以下句子中判斷使用者的情緒，並只回覆「快樂」、「悲傷」、「生氣」或「中性」其中一種：
句子：「{text}」"""
    emotion = safe_generate(prompt)
    return emotion if emotion in ["快樂", "悲傷", "生氣", "中性"] else "中性"

def detect_audio_emotion(audio_path, max_duration=30.0):
    try:
        audio_array, _ = librosa.load(audio_path, sr=feature_extractor.sampling_rate)
        max_len = int(feature_extractor.sampling_rate * max_duration)
        if len(audio_array) > max_len:
            audio_array = audio_array[:max_len]
        else:
            audio_array = np.pad(audio_array, (0, max_len - len(audio_array)))
        inputs = feature_extractor(audio_array, sampling_rate=feature_extractor.sampling_rate, return_tensors="pt").to(device)
        with torch.no_grad():
            logits = audio_model(**inputs).logits
            predicted_class = torch.argmax(logits, dim=1).item()
            return id2label[predicted_class]
    except Exception as e:
        print("[Error] Audio emotion:", e)
        return "未知"

def detect_facial_emotion(image_path):
    try:
        img = cv2.imread(image_path)
        results = face_emotion_detector.detect_emotions(img)
        if results:
            top_emotion = max(results[0]["emotions"], key=results[0]["emotions"].get)
            confidence = results[0]["emotions"][top_emotion]
            mapping = {
                "happy": "快樂",
                "sad": "悲傷",
                "angry": "生氣",
                "neutral": "中性"
            }
            return mapping.get(top_emotion, "中性"), confidence
        else:
            return "中性", 0.0
    except Exception as e:
        print("[錯誤] 臉部情緒辨識失敗：", e)
        return "未知", 0.0

def fuse_emotions(text_emotion, audio_emotion, facial_emotion=None, weights={"text": 0.4, "audio": 0.3, "facial": 0.3}):
    emotions = ["快樂", "悲傷", "生氣", "中性"]
    scores = {e: 0 for e in emotions}
    if text_emotion in scores:
        scores[text_emotion] += weights["text"]
    if audio_emotion in scores:
        scores[audio_emotion] += weights["audio"]
    if facial_emotion in scores:
        scores[facial_emotion] += weights["facial"]
    final = max(scores, key=scores.get)
    return final, scores
